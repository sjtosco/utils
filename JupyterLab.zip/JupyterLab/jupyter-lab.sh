#!/bin/bash
# if virtualenvwrapper.sh is in your PATH (i.e. installed with pip)
source /usr/local/bin/virtualenvwrapper.sh # if it's not in your PATH
workon _jupyterlab
jupyter-lab
deactivate

