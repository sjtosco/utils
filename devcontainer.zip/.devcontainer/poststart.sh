#!/bin/bash
poetry completions bash >> ~/.bash_completion
poetry install